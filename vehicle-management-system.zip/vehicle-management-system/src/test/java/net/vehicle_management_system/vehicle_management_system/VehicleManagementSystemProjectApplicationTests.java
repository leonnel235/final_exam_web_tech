package net.vehicle_management_system.vehicle_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleManagementSystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

package net.vehicle_management_system.vehicle_management_system.Service.Implement;

import net.vehicle_management_system.vehicle_management_system.Dto.ClientDTO;
import net.vehicle_management_system.vehicle_management_system.Dto.LoginDTO;
import net.vehicle_management_system.vehicle_management_system.Model.Client;
import net.vehicle_management_system.vehicle_management_system.Repository.ClientRepository;
import net.vehicle_management_system.vehicle_management_system.ResponseDisplay.LoginMessage;
import net.vehicle_management_system.vehicle_management_system.Service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ClientIMPL implements ClientService {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public String addclient(ClientDTO clientDTO) {
        // Encode the password before saving
        String encodedPassword = passwordEncoder.encode(clientDTO.getPassword());

        // Create a new Client entity from the ClientDTO
        Client client = new Client();
        client.setClientname(clientDTO.getClientname());
        client.setEmail(clientDTO.getEmail());
        client.setPassword(encodedPassword);

        // Save the client to the repository
        clientRepository.save(client);

        // Return the client name as a response (or another identifier if needed)
        return client.getClientname();
    }

    @Override
    public LoginMessage loginclient(LoginDTO loginDTO) {
        // Retrieve the client by email
        Client client = clientRepository.findByEmail(loginDTO.getEmail());

        if (client != null) {
            // Check if the provided password matches the stored password
            boolean isPwdRight = passwordEncoder.matches(loginDTO.getPassword(), client.getPassword());

            if (isPwdRight) {
                // Return a success message if the passwords match
                return new LoginMessage("Login Success", true);
            } else {
                // Return an error message if the password doesn't match
                return new LoginMessage("Password Not Match", false);
            }
        } else {
            // Return an error message if the email does not exist
            return new LoginMessage("Email not found", false);
        }
    }

    @Override
    public String updateClientById(int clientId, ClientDTO clientDTO) {
        Optional<Client> optionalClient = clientRepository.findById(clientId);
        if (optionalClient.isPresent()) {
            Client client = optionalClient.get();
            client.setClientname(clientDTO.getClientname());
            client.setEmail(clientDTO.getEmail());
            client.setPassword(passwordEncoder.encode(clientDTO.getPassword())); // Re-encode the password
            clientRepository.save(client);
            return client.getClientname();
        } else {
            throw new RuntimeException("Client not found with id: " + clientId);
        }
    }

    @Override
    public void deleteClientById(int clientId) {
        Optional<Client> optionalClient = clientRepository.findById(clientId);
        if (optionalClient.isPresent()) {
            clientRepository.delete(optionalClient.get());
        } else {
            throw new RuntimeException("Client not found with id: " + clientId);
        }
    }

    @Override
    public List<ClientDTO> searchClientByName(String clientName) {
        List<Client> clients = clientRepository.findByClientnameContaining(clientName);
        // Convert entities to DTOs
        List<ClientDTO> clientDTOs = clients.stream()
                .map(client -> new ClientDTO(client.getClientname(), client.getEmail(), client.getPassword()))
                .collect(Collectors.toList());
        return clientDTOs;
    }

}

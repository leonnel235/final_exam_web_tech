package net.vehicle_management_system.vehicle_management_system.Controller;

import net.vehicle_management_system.vehicle_management_system.Dto.VehicleDTO;
import net.vehicle_management_system.vehicle_management_system.Exception.TechNotFoundException;
import net.vehicle_management_system.vehicle_management_system.Exception.VechNotFoundException;
import net.vehicle_management_system.vehicle_management_system.Model.Vehicle;
import net.vehicle_management_system.vehicle_management_system.Repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/vehicle")
public class VehicleController {

    @Autowired
    private VehicleRepository vehicleRepository;

    // Create a new vehicle
    @PostMapping(path="/vehicle")
    public Vehicle createVehicle (@RequestBody VehicleDTO vehicleDTO) {
        Vehicle vehicle = new Vehicle();
        vehicle.setVech_name(vehicleDTO.getVech_name());
        vehicle.setVech_color(vehicleDTO.getVech_color());
        vehicle.setVech_licence(vehicleDTO.getVech_licence());
        return vehicleRepository.save(vehicle);
    }

    // Get all vehicles
    @GetMapping(path="/vehicle")
    public List<VehicleDTO> getAllVechicle() {
        return vehicleRepository.findAll().stream()
                .map(vehicle -> new VehicleDTO(
                        vehicle.getVech_name(),
                        vehicle.getVech_color(),
                        vehicle.getVech_licence()
                ))
                .collect(Collectors.toList());
    }

    // Get a Vehicle by ID
    @GetMapping(path="/vehicle/{id}")
    public Vehicle getVehicleById(@PathVariable("id") int vehicleid) {
        return vehicleRepository.findById( vehicleid)
                .orElseThrow(() -> new VechNotFoundException( vehicleid));
    }

    // Update a Vehicle by ID
    @PutMapping(path="/vehicle/{id}")
    public Vehicle updatevihicles(@RequestBody VehicleDTO vehicleDTO, @PathVariable("id") int  vehicleid) {
        return vehicleRepository.findById( vehicleid)
                .map(vehicle -> {
                    vehicle.setVech_name(vehicleDTO.getVech_name());
                    vehicle.setVech_color(vehicleDTO.getVech_color());
                    vehicle.setVech_licence(vehicleDTO.getVech_licence());
                    return vehicleRepository.save(vehicle);
                })
                .orElseThrow(() -> new VechNotFoundException( vehicleid));
    }

    // Delete a vehicle by ID
    @DeleteMapping(path="/vehicle/{id}")
    public String deletevehicle(@PathVariable("id") int  vehicleid) {
        if (!vehicleRepository.existsById( vehicleid)) {
            throw new TechNotFoundException( vehicleid);
        }
        vehicleRepository.deleteById( vehicleid);
        return "Vehicle with ID " +  vehicleid + " deleted successfully.";
    }

    // Search Vehicle by name using a path variable
    @GetMapping(path="/vehicle/search/{vech_name}")
    public List<VehicleDTO> searchvehicleByName(@PathVariable("vech_name") String vechName) {
        return vehicleRepository.findAll().stream()
                .filter( vehicle-> vehicle.getVech_name().contains(vechName))
                .map(vehicle -> new VehicleDTO(
                        vehicle.getVech_name(),
                        vehicle.getVech_color(),
                        vehicle.getVech_licence()
                ))
                .collect(Collectors.toList());
    }

}
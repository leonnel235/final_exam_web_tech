package net.vehicle_management_system.vehicle_management_system.Exception;

public class VechColorNotFoundException extends RuntimeException{
    public VechColorNotFoundException(Integer id) {
        super("Could not find Vehicle Color with such " + id);

    }
}

package net.vehicle_management_system.vehicle_management_system.Exception;

public class TechNotFoundException extends RuntimeException{
    public TechNotFoundException( Integer id) {
        super("Could not find Technician with such " + id);

    }
}

package net.vehicle_management_system.vehicle_management_system.Controller;

import net.vehicle_management_system.vehicle_management_system.Dto.BookingDTO;
import net.vehicle_management_system.vehicle_management_system.Exception.BookingNotFoundException;
import net.vehicle_management_system.vehicle_management_system.Model.Booking;
import net.vehicle_management_system.vehicle_management_system.Repository.*;
import net.vehicle_management_system.vehicle_management_system.Repository.TechRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private TechRepository techRepository;

    @Autowired
    private VehicleColorRepository vehicleColorRepository;

    // Save a new booking
    @PostMapping(path = "/save")
    public Booking saveBooking(@RequestBody BookingDTO bookingDTO) {
        Booking booking = new Booking();
        booking.setBooking_price(bookingDTO.getBooking_price());
        booking.setBooking_date(bookingDTO.getBooking_date());
        booking.setClient(clientRepository.findById(bookingDTO.getClientid())
                .orElseThrow(() -> new RuntimeException("Client not found")));
        booking.setVehicle(vehicleRepository.findById(bookingDTO.getVech_id())
                .orElseThrow(() -> new RuntimeException("Vehicle not found")));
        booking.setTechnician(techRepository.findById(bookingDTO.getTech_id())
                .orElseThrow(() -> new RuntimeException("Technician not found")));
        booking.setVehicleColor(vehicleColorRepository.findById(bookingDTO.getColor_id())
                .orElseThrow(() -> new RuntimeException("Vehicle Color not found")));
        return bookingRepository.save(booking);
    }

    // Get all bookings
    @GetMapping(path = "/bookings")
    public List<BookingDTO> getAllBookings() {
        return bookingRepository.findAll().stream()
                .map(booking -> new BookingDTO(
                        booking.getBooking_price(),
                        booking.getBooking_date(),
                        booking.getClient().getClientid(),
                        booking.getVehicle().getVech_id(),
                        booking.getTechnician().getTech_id(),
                        booking.getVehicleColor().getColor_id()
                ))
                .collect(Collectors.toList());
    }

    // Get booking by ID
    @GetMapping(path = "/bookings/{id}")
    public BookingDTO getBookingById(@PathVariable Integer id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new BookingNotFoundException(id));
        return new BookingDTO(
                booking.getBooking_price(),
                booking.getBooking_date(),
                booking.getClient().getClientid(),
                booking.getVehicle().getVech_id(),
                booking.getTechnician().getTech_id(),
                booking.getVehicleColor().getColor_id()
        );
    }

    // Update booking
    @PutMapping(path = "/bookings/{id}")
    public Booking updateBooking(@RequestBody BookingDTO bookingDTO, @PathVariable Integer id) {
        return bookingRepository.findById(id)
                .map(existingBooking -> {
                    existingBooking.setBooking_price(bookingDTO.getBooking_price());
                    existingBooking.setBooking_date(bookingDTO.getBooking_date());
                    existingBooking.setClient(clientRepository.findById(bookingDTO.getClientid())
                            .orElseThrow(() -> new RuntimeException("Client not found")));
                    existingBooking.setVehicle(vehicleRepository.findById(bookingDTO.getVech_id())
                            .orElseThrow(() -> new RuntimeException("Vehicle not found")));
                    existingBooking.setTechnician(techRepository.findById(bookingDTO.getTech_id())
                            .orElseThrow(() -> new RuntimeException("Technician not found")));
                    existingBooking.setVehicleColor(vehicleColorRepository.findById(bookingDTO.getColor_id())
                            .orElseThrow(() -> new RuntimeException("Vehicle Color not found")));
                    return bookingRepository.save(existingBooking);
                })
                .orElseThrow(() -> new BookingNotFoundException(id));
    }

    // Delete booking by ID
    @DeleteMapping(path = "/booking/{id}")
    public String deleteBooking(@PathVariable Integer id) {
        if (!bookingRepository.existsById(id)) {
            throw new BookingNotFoundException(id);
        }
        bookingRepository.deleteById(id);
        return "Booking with ID " + id + " deleted successfully.";
    }

    // Find bookings by client name
    @GetMapping(path = "/bookings/search/{clientname}")
    public List<BookingDTO> findBookingsByClientName(@RequestParam String name) {
        return bookingRepository.findAll().stream()
                .filter(booking -> booking.getClient().getClientname().contains(name))
                .map(booking -> new BookingDTO(
                        booking.getBooking_price(),
                        booking.getBooking_date(),
                        booking.getClient().getClientid(),
                        booking.getVehicle().getVech_id(),
                        booking.getTechnician().getTech_id(),
                        booking.getVehicleColor().getColor_id()
                ))
                .collect(Collectors.toList());
    }
}

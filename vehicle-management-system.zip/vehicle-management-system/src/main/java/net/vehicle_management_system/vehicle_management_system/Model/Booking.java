package net.vehicle_management_system.vehicle_management_system.Model;

import jakarta.persistence.*;

@Entity
@Table(name = "booking")
public class Booking {

    @Id
    @Column(name = "booking_id", length = 45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer booking_id;

    @Column(name = "booking_price", length = 255)
    private String booking_price;

    @Column(name = "booking_date", length = 255)
    private String booking_date;

    @ManyToOne
    @JoinColumn(name = "clientid") // Foreign key column in the booking table
    private Client client;

    @ManyToOne
    @JoinColumn(name = "vech_id") // Adjust foreign key column name as needed
    private Vehicle vehicle;

    @ManyToOne
    @JoinColumn(name = "tech_id") // Adjust foreign key column name as needed
    private Technician technician;

    @ManyToOne
    @JoinColumn(name = "color_id") // Adjust foreign key column name as needed
    private VehicleColor vehicleColor;

    public Booking(Integer booking_id, String booking_price, String booking_date, Client client, Vehicle vehicle, Technician technician, VehicleColor vehicleColor) {
        this.booking_id = booking_id;
        this.booking_price = booking_price;
        this.booking_date = booking_date;
        this.client = client;
        this.vehicle = vehicle;
        this.technician = technician;
        this.vehicleColor = vehicleColor;
    }

    public Booking() {
    }

    public Integer getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(Integer booking_id) {
        this.booking_id = booking_id;
    }

    public String getBooking_price() {
        return booking_price;
    }

    public void setBooking_price(String booking_price) {
        this.booking_price = booking_price;
    }

    public String getBooking_date() {
        return booking_date;
    }

    public void setBooking_date(String booking_date) {
        this.booking_date = booking_date;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Technician getTechnician() {
        return technician;
    }

    public void setTechnician(Technician technician) {
        this.technician = technician;
    }

    public VehicleColor getVehicleColor() {
        return vehicleColor;
    }

    public void setVehicleColor(VehicleColor vehicleColor) {
        this.vehicleColor = vehicleColor;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "booking_id=" + booking_id +
                ", booking_price='" + booking_price + '\'' +
                ", booking_date='" + booking_date + '\'' +
                ", client=" + client +
                ", vehicle=" + vehicle +
                ", technician=" + technician +
                ", vehicleColor=" + vehicleColor +
                '}';
    }
}

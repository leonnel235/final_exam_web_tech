package net.vehicle_management_system.vehicle_management_system.Service;
import net.vehicle_management_system.vehicle_management_system.Dto.ClientDTO;
import net.vehicle_management_system.vehicle_management_system.Dto.LoginDTO;
import net.vehicle_management_system.vehicle_management_system.ResponseDisplay.LoginMessage;

import java.util.List;

public interface ClientService {
   String addclient(ClientDTO clientDTO);
   LoginMessage loginclient(LoginDTO loginDTO);
   String updateClientById(int clientId, ClientDTO clientDTO);
   void deleteClientById(int clientId);
   List<ClientDTO> searchClientByName(String clientName);
}
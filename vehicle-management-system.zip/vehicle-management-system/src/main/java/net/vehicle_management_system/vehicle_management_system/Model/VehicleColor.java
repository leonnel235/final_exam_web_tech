package net.vehicle_management_system.vehicle_management_system.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="vehiclecolor")
public class VehicleColor {
    @Id
    @Column(name = "color_id", length = 45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int color_id;
    @Column(name = "color_name", length = 255)
    private String color_name;
    @Column(name = "color_type", length = 255)
    private String color_type;
    @Column(name = "color_price", length = 255)
    private String color_price;
    @OneToMany(mappedBy = "vehicleColor", cascade = CascadeType.ALL)
    private List<Booking> bookings = new ArrayList<>();


    public VehicleColor(int color_id, String color_name, String color_type, String color_price, List<Booking> bookings) {
        this.color_id = color_id;
        this.color_name = color_name;
        this.color_type = color_type;
        this.color_price = color_price;
        this.bookings = bookings;
    }
    public VehicleColor(){

    }

    public int getColor_id() {
        return color_id;
    }

    public void setColor_id(int color_id) {
        this.color_id = color_id;
    }

    public String getColor_name() {
        return color_name;
    }

    public void setColor_name(String color_name) {
        this.color_name = color_name;
    }

    public String getColor_type() {
        return color_type;
    }

    public void setColor_type(String color_type) {
        this.color_type = color_type;
    }

    public String getColor_price() {
        return color_price;
    }

    public void setColor_price(String color_price) {
        this.color_price = color_price;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    @Override
    public String toString() {
        return "VehicleColor{" +
                "id=" + color_id +
                ", color_name='" + color_name + '\'' +
                ", color_type='" + color_type + '\'' +
                ", color_price='" + color_price + '\'' +
                ", bookings=" + bookings +
                '}';
    }
}

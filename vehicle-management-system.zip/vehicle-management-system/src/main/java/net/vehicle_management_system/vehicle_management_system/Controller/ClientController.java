package net.vehicle_management_system.vehicle_management_system.Controller;

import net.vehicle_management_system.vehicle_management_system.Dto.ClientDTO;
import net.vehicle_management_system.vehicle_management_system.Dto.LoginDTO;
import net.vehicle_management_system.vehicle_management_system.ResponseDisplay.LoginMessage;
import net.vehicle_management_system.vehicle_management_system.Service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3001")
@RequestMapping("/api/v1/client")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @PostMapping(path = "/clients")
    public String saveClient(@RequestBody ClientDTO clientDTO) {
        System.out.println("Received ClientDTO: " + clientDTO);
        String id = clientService.addclient(clientDTO);
        return id;
    }



    // Login client
    @PostMapping(path = "/login")
    public ResponseEntity<?> loginclient(@RequestBody LoginDTO loginDTO) {
        System.out.println("Received LoginDTO: " + loginDTO);
        LoginMessage loginResponse = clientService.loginclient(loginDTO);
        return ResponseEntity.ok(loginResponse);
    }

    // Update client by ID
    @PutMapping(path = "/update/{id}")
    public ResponseEntity<?> updateClient(@PathVariable("id") int clientId, @RequestBody ClientDTO clientDTO) {
        System.out.println("Updating client with ID: " + clientId);
        String updatedClientName = clientService.updateClientById(clientId, clientDTO);
        return ResponseEntity.ok("Client updated: " + updatedClientName);
    }

    // Delete client by ID
    @DeleteMapping(path = "/delete/{id}")
    public ResponseEntity<?> deleteClient(@PathVariable("id") int clientId) {
        System.out.println("Deleting client with ID: " + clientId);
        clientService.deleteClientById(clientId);
        return ResponseEntity.ok("Client deleted with ID: " + clientId);
    }

    // Search clients by client name
    @GetMapping(path = "/search/{clientname}")
    public ResponseEntity<?> searchClientByName(@PathVariable("clientname") String clientName) {
        System.out.println("Searching clients with name: " + clientName);
        List<ClientDTO> clients = clientService.searchClientByName(clientName);
        return ResponseEntity.ok(clients);
    }
}

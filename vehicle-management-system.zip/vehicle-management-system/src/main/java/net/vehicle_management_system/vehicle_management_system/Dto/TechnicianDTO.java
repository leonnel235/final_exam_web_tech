package net.vehicle_management_system.vehicle_management_system.Dto;

public class TechnicianDTO {
    public String tech_name;
    public String tech_email;
    public String tech_prof;

    public TechnicianDTO(String tech_name, String tech_email, String tech_prof) {
        this.tech_name = tech_name;
        this.tech_email = tech_email;
        this.tech_prof = tech_prof;
    }
    public TechnicianDTO(){

    }

    public String getTech_name() {
        return tech_name;
    }

    public void setTech_name(String tech_name) {
        this.tech_name = tech_name;
    }

    public String getTech_email() {
        return tech_email;
    }

    public void setTech_email(String tech_email) {
        this.tech_email = tech_email;
    }

    public String gettech_prof() {
        return tech_prof;
    }

    public void settech_prof(String tech_prof) {
        this.tech_prof = tech_prof;
    }

    @Override
    public String toString() {
        return "TechnicianDTO{" +
                "tech_name='" + tech_name + '\'' +
                ", tech_email='" + tech_email + '\'' +
                ", tech_prof='" + tech_prof + '\'' +
                '}';
    }
}

package net.vehicle_management_system.vehicle_management_system.Controller;

import net.vehicle_management_system.vehicle_management_system.Dto.VehicleColorDTO;
import net.vehicle_management_system.vehicle_management_system.Exception.VechColorNotFoundException;
import net.vehicle_management_system.vehicle_management_system.Model.VehicleColor;
import net.vehicle_management_system.vehicle_management_system.Repository.VehicleColorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/vehiclecolor")
public class VehicleColorController {

    @Autowired
    private VehicleColorRepository vehicleColorRepository;

    // Create a new vehicle
    @PostMapping(path ="/vehiclecolor")
    public VehicleColor createVehicle (@RequestBody VehicleColorDTO vehicleColorDTO  ) {
        VehicleColor vehicleColor = new VehicleColor();
        vehicleColor.setColor_name(vehicleColorDTO.getColor_name());
        vehicleColor.setColor_type(vehicleColorDTO.getColor_type());
        vehicleColor.setColor_price(vehicleColorDTO.getColor_price());
        return vehicleColorRepository.save(vehicleColor);
    }

    // Get all vehicles
    @GetMapping(path ="/vehiclecolor")
    public List<VehicleColorDTO> getAllVechicle() {
        return vehicleColorRepository.findAll().stream()
                .map(vehicleColor  -> new VehicleColorDTO(
                        vehicleColor.getColor_name(),
                        vehicleColor.getColor_type(),
                        vehicleColor.getColor_price()
                ))
                .collect(Collectors.toList());
    }

    // Get a Vehicle by ID
    @GetMapping(path ="/vehiclecolor/{id}")
    public VehicleColor getVehicleById(@PathVariable("id") int vehicleid) {
        return vehicleColorRepository.findById(vehicleid)
                .orElseThrow(() -> new VechColorNotFoundException(vehicleid));
    }

    // Update a Vehicle by ID
    @PutMapping(path ="/vehiclecolor/{id}")
    public VehicleColor updatevehicles(@RequestBody VehicleColorDTO vehicleColorDTO, @PathVariable int vehicleid) {
        return vehicleColorRepository.findById(vehicleid)
                .map(vehicleColor  -> {
                    vehicleColor.setColor_name(vehicleColorDTO.getColor_name());
                    vehicleColor.setColor_type(vehicleColorDTO.getColor_type());
                    vehicleColor.setColor_price(vehicleColorDTO.getColor_price());
                    return vehicleColorRepository.save(vehicleColor);
                })
                .orElseThrow(() -> new VechColorNotFoundException(vehicleid));
    }

    // Delete a vehicle by ID
    @DeleteMapping(path ="/vehiclecolor/{id}")
    public String deletevehicle(@PathVariable("id") int vehicleid) {
        if (!vehicleColorRepository.existsById(vehicleid)) {
            throw new VechColorNotFoundException(vehicleid);
        }
        vehicleColorRepository.deleteById(vehicleid);
        return "Vehicle Color with ID " + vehicleid + " deleted successfully.";
    }

    // Search Vehicle by name using a path variable
    @GetMapping(path ="/vehiclecolor/search/{color_name}")
    public List<VehicleColorDTO> searchvehicleByName(@PathVariable("color_name") String colName) {
        return vehicleColorRepository.findAll().stream()
                .filter( vehicleColor -> vehicleColor.getColor_name().contains(colName))
                .map(vehicleColor  -> new VehicleColorDTO(
                        vehicleColor.getColor_name(),
                        vehicleColor.getColor_type(),
                        vehicleColor.getColor_price()
                ))
                .collect(Collectors.toList());
    }

}

package net.vehicle_management_system.vehicle_management_system.Exception;

public class VechNotFoundException extends RuntimeException{
    public VechNotFoundException(Integer id) {
        super("Could not find Vehicle with such " + id);

    }
}

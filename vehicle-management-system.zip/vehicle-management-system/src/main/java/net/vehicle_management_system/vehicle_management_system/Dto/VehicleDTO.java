package net.vehicle_management_system.vehicle_management_system.Dto;

public class VehicleDTO {
    private String vech_name;
    private String vech_color;
    private String vech_licence;

    public VehicleDTO(String vech_name, String vech_color, String vech_licence) {
        this.vech_name = vech_name;
        this.vech_color = vech_color;
        this.vech_licence = vech_licence;
    }
    public VehicleDTO(){

    }

    public String getVech_name() {
        return vech_name;
    }

    public void setVech_name(String vech_name) {
        this.vech_name = vech_name;
    }

    public String getVech_color() {
        return vech_color;
    }

    public void setVech_color(String vech_color) {
        this.vech_color = vech_color;
    }

    public String getVech_licence() {
        return vech_licence;
    }

    public void setVech_licence(String vech_licence) {
        this.vech_licence = vech_licence;
    }

    @Override
    public String toString() {
        return "VehicleDTO{" +
                "vech_name='" + vech_name + '\'' +
                ", vech_color='" + vech_color + '\'' +
                ", vech_licence='" + vech_licence + '\'' +
                '}';
    }

}

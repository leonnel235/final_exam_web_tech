package net.vehicle_management_system.vehicle_management_system.Controller;

import net.vehicle_management_system.vehicle_management_system.Dto.TechnicianDTO;
import net.vehicle_management_system.vehicle_management_system.Exception.TechNotFoundException;
import net.vehicle_management_system.vehicle_management_system.Model.Technician;
import net.vehicle_management_system.vehicle_management_system.Repository.TechRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/techs")
public class TechController {

    @Autowired
    private TechRepository techRepository;

    // Create a new technician
    @PostMapping(path = "/techs")
    public Technician createTechnician(@RequestBody TechnicianDTO technicianDTO) {
        Technician technician = new Technician();
        technician.setTech_name(technicianDTO.getTech_name());
        technician.setTech_email(technicianDTO.getTech_email());
        technician.settech_prof(technicianDTO.gettech_prof());
        return techRepository.save(technician);
    }

    // Get all technicians
    @GetMapping(path = "/techs")
    public List<TechnicianDTO> getAllTechnicians() {
        return techRepository.findAll().stream()
                .map(technician -> new TechnicianDTO(
                        technician.getTech_name(),
                        technician.getTech_email(),
                        technician.gettech_prof()
                        // Password is not exposed
                ))
                .collect(Collectors.toList());
    }

    // Get a technician by ID
    @GetMapping(path = "/techs/{id}")
    public Technician getTechnicianById(@PathVariable("id") int tech_Id) {
        return techRepository.findById(tech_Id)
                .orElseThrow(() -> new TechNotFoundException(tech_Id));
    }

    // Update a technician by I
    @PutMapping(path = "/techs/{id}")
    public Technician updateTechnician( @PathVariable("id") int tech_Id,@RequestBody TechnicianDTO technicianDTO) {
        return techRepository.findById(tech_Id)
                .map(technician -> {
                    technician.setTech_name(technicianDTO.getTech_name());
                    technician.setTech_email(technicianDTO.getTech_email());
                    technician.settech_prof(technicianDTO.gettech_prof());
                    return techRepository.save(technician);
                })
                .orElseThrow(() -> new TechNotFoundException(tech_Id));
    }

    // Delete a technician by ID
    @DeleteMapping(path = "/techs/{id}")
    public String deleteTechnician(@PathVariable("id") int tech_Id) {
        if (!techRepository.existsById(tech_Id)) {
            throw new TechNotFoundException(tech_Id);
        }
        techRepository.deleteById(tech_Id);
        return "Technician with ID " + tech_Id + " deleted successfully.";
    }

    // Search technicians by name using a path variable
    @GetMapping(path = "/techs/search/{tech_name}")
    public List<TechnicianDTO> searchTechniciansByName(@PathVariable("tech_name") String techName) {
        return techRepository.findAll().stream()
                .filter(technician -> technician.getTech_name().contains(techName))
                .map(technician -> new TechnicianDTO(
                        technician.getTech_name(),
                        technician.getTech_email(),
                        technician.gettech_prof()
                ))
                .collect(Collectors.toList());
    }

}

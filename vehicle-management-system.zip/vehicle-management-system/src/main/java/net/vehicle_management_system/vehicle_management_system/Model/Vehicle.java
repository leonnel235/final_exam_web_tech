package net.vehicle_management_system.vehicle_management_system.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name="vehicle")
public class Vehicle {
    @Id
    @Column(name = "vech_id", length = 45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int vech_id;
    @Column(name = "vech_name", length = 255)
    private String vech_name;
    @Column(name = "vech_color", length = 255)
    private String vech_color;
    @Column(name = "vech_licence", length = 255)
    private String vech_licence;
    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL)
    private List<Booking> bookings = new ArrayList<>();


    public Vehicle(int vech_id, String vech_name, String vech_color, String vech_licence, List<Booking> bookings) {
        this.vech_id = vech_id;
        this.vech_name = vech_name;
        this.vech_color = vech_color;
        this.vech_licence = vech_licence;
        this.bookings = bookings;
    }
    public Vehicle(){

    }

    public int getVech_id() {
        return vech_id;
    }

    public void setVech_id(int vech_id) {
        this.vech_id = vech_id;
    }

    public String getVech_name() {
        return vech_name;
    }

    public void setVech_name(String vech_name) {
        this.vech_name = vech_name;
    }

    public String getVech_color() {
        return vech_color;
    }

    public void setVech_color(String vech_color) {
        this.vech_color = vech_color;
    }

    public String getVech_licence() {
        return vech_licence;
    }

    public void setVech_licence(String vech_licence) {
        this.vech_licence = vech_licence;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "id=" + vech_id +
                ", vech_name='" + vech_name + '\'' +
                ", vech_color='" + vech_color + '\'' +
                ", vech_licence='" + vech_licence + '\'' +
                ", bookings=" + bookings +
                '}';
    }
}

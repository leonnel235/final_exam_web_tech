package net.vehicle_management_system.vehicle_management_system.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/index")
    public String home() {
        return "index"; // Refers to index.html in src/main/resources/templates
    }

    @GetMapping("/login")
    public String login() {
        return "login"; // Refers to login.html
    }

    @GetMapping("/signup")
    public String signup() {
        return "signup"; // Refers to signup.html
    }

    @GetMapping("/clients")
    public String manageClients() {
        return "clients"; // Refers to clients.html
    }

    @GetMapping("/vehicles")
    public String manageVehicles() {
        return "vehicles"; // Refers to vehicles.html
    }

    @GetMapping("/technicians")
    public String manageTechnicians() {
        return "technicians"; // Refers to technicians.html
    }

    @GetMapping("/vehicle_types")
    public String manageVehicleTypes() {
        return "vehicle_types"; // Refers to vehicle_types.html
    }
    @GetMapping("/homepage")
    public String homepage() {
        return "homepage"; // Refers to vehicle_types.html
    }

    @GetMapping("/dasboard")
    public String dashboard() {
        return "dasboard"; // Refers to vehicle_types.html
    }

}

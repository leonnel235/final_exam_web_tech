package net.vehicle_management_system.vehicle_management_system.Dto;

public class BookingDTO {
    private String booking_price;
    private String booking_date;
    private int clientid;
    private int  tech_id;
    private int  vech_id;
    private int  color_id;

    public BookingDTO(String booking_price, String booking_date, int clientid, int tech_id, int vech_id, int color_id) {
        this.booking_price = booking_price;
        this.booking_date = booking_date;
        this.clientid = clientid;
        this.tech_id = tech_id;
        this.vech_id = vech_id;
        this.color_id = color_id;
    }
    public BookingDTO() {
    }

    public String getBooking_price() {
        return booking_price;
    }

    public void setBooking_price(String booking_price) {
        this.booking_price = booking_price;
    }

    public String getBooking_date() {
        return booking_date;
    }

    public void setBooking_date(String booking_date) {
        this.booking_date = booking_date;
    }

    public int getClientid() {
        return clientid;
    }

    public void setClientid(int clientid) {
        this.clientid = clientid;
    }

    public int getTech_id() {
        return tech_id;
    }

    public void setTech_id(int tech_id) {
        this.tech_id = tech_id;
    }

    public int getVech_id() {
        return vech_id;
    }

    public void setVech_id(int vech_id) {
        this.vech_id = vech_id;
    }

    public int getColor_id() {
        return color_id;
    }

    public void setColor_id(int color_id) {
        this.color_id = color_id;
    }

    @Override
    public String toString() {
        return "BookingDTO{" +
                "booking_price='" + booking_price + '\'' +
                ", booking_date='" + booking_date + '\'' +
                ", clientid=" + clientid +
                ", tech_id=" + tech_id +
                ", vech_id=" + vech_id +
                ", color_id=" + color_id +
                '}';
    }
}
package net.vehicle_management_system.vehicle_management_system.Repository;
import net.vehicle_management_system.vehicle_management_system.Model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@EnableJpaRepositories
@Repository
public interface ClientRepository extends JpaRepository<Client,Integer>
{
    Optional<Client> findOneByEmailAndPassword(String email, String password);
    Client findByEmail(String email);

    List<Client> findByClientnameContaining(String clientName);
}
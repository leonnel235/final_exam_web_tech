package net.vehicle_management_system.vehicle_management_system.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="client")
public class Client {
    @Id
    @Column(name = "client_id", length = 45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonProperty("clientId")
    private int clientid;
    @Column(name = "client_name", length = 255)
    private String clientname;
    @Column(name = "email", unique = true, length = 255)
    private String email;
    @Column(name = "password",unique = true, length = 255)
    private String password;
    @OneToMany(mappedBy = "client", cascade = CascadeType.ALL)
    private List<Booking> bookings = new ArrayList<>();

    public Client() {
    }

    public Client(int clientid, String clientname, String email, String password) {
        this.clientid = clientid;
        this.clientname = clientname;
        this.email = email;
        this.password = password;
        this.bookings = bookings;

    }

    public int getClientid() {
        return clientid;
    }

    public void setClientid(int clientid) {
        this.clientid = clientid;
    }

    public String getClientname() {
        return clientname;
    }

    public void setClientname(String clientname) {
        this.clientname = clientname;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    public int getclientid() {
        return clientid;
    }

    public void setclientid(int clientid) {
        this.clientid = clientid;
    }

    public String getclientname() {
        return clientname;
    }

    public void setclientname(String clientname) {
        this.clientname = clientname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Client{" +
                "clientid=" + clientid +
                ", clientname='" + clientname + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", bookings=" + bookings +
                '}';
    }
}
//create getters and setters
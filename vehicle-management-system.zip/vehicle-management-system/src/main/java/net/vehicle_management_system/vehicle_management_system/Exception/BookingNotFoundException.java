package net.vehicle_management_system.vehicle_management_system.Exception;

public class BookingNotFoundException extends RuntimeException{
    public BookingNotFoundException( Integer id) {
        super("Could not find Booking with such " + id);

    }
}

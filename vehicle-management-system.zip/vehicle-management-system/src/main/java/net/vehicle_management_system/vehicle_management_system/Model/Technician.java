package net.vehicle_management_system.vehicle_management_system.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name="technician")
public class Technician {
    @Id
    @Column(name = "tech_id", length = 45)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int tech_id;
    @Column(name = "tech_name", length = 255)
    private String tech_name;
    @Column(name = " tech_email", length = 255)
    private String tech_email;
    @Column(name = "tech_prof", length = 255)
    private String tech_prof;
    @OneToMany(mappedBy = "technician", cascade = CascadeType.ALL)
    private List<Booking> bookings = new ArrayList<>();


    public Technician(int tech_id, String tech_name, String tech_email, String tech_prof, List<Booking> bookings) {
        this.tech_id = tech_id;
        this.tech_name = tech_name;
        this.tech_email = tech_email;
        this.tech_prof = tech_prof;
        this.bookings = bookings;

    }
    public Technician(){

    }

    @Override
    public String toString() {
        return "Technician{" +
                "id=" + tech_id +
                ", tech_name='" + tech_name + '\'' +
                ", tech_email='" + tech_email + '\'' +
                ", tech_prof='" + tech_prof + '\'' +
                ", bookings=" + bookings +
                '}';
    }

    public int getTech_id() {
        return tech_id;
    }

    public void setTech_id(int tech_id) {
        this.tech_id = tech_id;
    }

    public String getTech_name() {
        return tech_name;
    }

    public void setTech_name(String tech_name) {
        this.tech_name = tech_name;
    }

    public String getTech_email() {
        return tech_email;
    }

    public void setTech_email(String tech_email) {
        this.tech_email = tech_email;
    }

    public String gettech_prof() {
        return tech_prof;
    }

    public void settech_prof(String tech_prof) {
        this.tech_prof = tech_prof;
    }

    public List<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

}

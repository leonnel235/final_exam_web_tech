package net.vehicle_management_system.vehicle_management_system.Dto;

public class VehicleColorDTO {
    private String color_name;
    private String color_type;
    private String color_price;
    public VehicleColorDTO(String color_name, String color_type, String color_price) {
        this.color_name = color_name;
        this.color_type = color_type;
        this.color_price = color_price;
    }

    public String getColor_name() {
        return color_name;
    }

    public void setColor_name(String color_name) {
        this.color_name = color_name;
    }

    public String getColor_type() {
        return color_type;
    }

    public void setColor_type(String color_type) {
        this.color_type = color_type;
    }

    public String getColor_price() {
        return color_price;
    }

    public void setColor_price(String color_price) {
        this.color_price = color_price;
    }

    public VehicleColorDTO(){

    }
    @Override
    public String toString() {
        return "VehicleColorDTO{" +
                "color_name='" + color_name + '\'' +
                ", color_type='" + color_type + '\'' +
                ", color_price='" + color_price + '\'' +
                '}';
    }
}

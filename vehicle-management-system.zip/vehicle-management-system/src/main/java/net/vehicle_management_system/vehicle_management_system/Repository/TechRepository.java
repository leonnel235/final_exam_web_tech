package net.vehicle_management_system.vehicle_management_system.Repository;

import net.vehicle_management_system.vehicle_management_system.Model.Technician;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TechRepository extends JpaRepository<Technician, Integer> {
}

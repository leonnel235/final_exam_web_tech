package net.vehicle_management_system.vehicle_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class VehicleManagementSystemProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleManagementSystemProjectApplication.class, args);
	}
}


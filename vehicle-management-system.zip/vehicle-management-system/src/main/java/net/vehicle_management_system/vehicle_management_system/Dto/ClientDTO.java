package net.vehicle_management_system.vehicle_management_system.Dto;

public class ClientDTO {

    private String clientname;
    private String email;
    private String password;

    // Constructor with parameters
    public ClientDTO(String clientname, String email, String password) {
        this.clientname = clientname;
        this.email = email;
        this.password = password;
    }

    // Default constructor
    public ClientDTO() {
    }

    // Getter for clientname
    public String getClientname() {
        return clientname;
    }

    // Setter for clientname
    public void setClientname(String clientname) {
        this.clientname = clientname;
    }

    // Getter for email
    public String getEmail() {
        return email;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }

    // Override toString() for better readability
    @Override
    public String toString() {
        return "ClientDTO{" +
                "clientname='" + clientname + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
